import React, { useState, useEffect } from "react";
import { Navigation } from "./components/navigation"; // Import Navigation
import { Header } from "./components/header";
import { Features } from "./components/features";
import { About } from "./components/about";
import { Services } from "./components/services";
import { Gallery } from "./components/gallery";

import { Team } from "./components/team";
import { Contact } from "./components/contact";
import JsonData from "./data/data.json";
import SmoothScroll from "smooth-scroll";
import AOS from "aos";
import "aos/dist/aos.css";
import "./App.css";

export const scroll = new SmoothScroll('a[href*="#"]', {
  speed: 1000,
  speedAsDuration: true,
});

const App = () => {
  const [landingPageData, setLandingPageData] = useState({});
  const [theme, setTheme] = useState('light'); // Default to light theme

  // Initialize AOS for animations
  useEffect(() => {
    setLandingPageData(JsonData);
    AOS.init({
      duration: 1000, // Animation duration in ms
      easing: "ease-in-out", // Animation easing type
      once: true, // Only animate once when scrolling
    });

    // Check the current time and set the theme accordingly
    const hours = new Date().getHours();
    const defaultTheme = hours >= 7 && hours < 19 ? 'light' : 'dark'; // Daytime = light, Night = dark
    setTheme(defaultTheme);
    document.documentElement.setAttribute('data-theme', defaultTheme);

    // Load theme from localStorage if set
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.setAttribute('data-theme', savedTheme);
    }
  }, []);

  // Toggle between light and dark themes
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme); // Save theme in localStorage
  };

  return (
    <div>
      {/* Theme toggle button */}
      <Navigation theme={theme} toggleTheme={toggleTheme} />

      {/* Rest of the App */}
      <Header data={landingPageData.Header} />
      <Features data={landingPageData.Features} />
      <About data={landingPageData.About} />
      <Services data={landingPageData.Services} />
      <Gallery data={landingPageData.Gallery} />
      
      <Team data={landingPageData.Team} />
      <Contact data={landingPageData.Contact} />

      
      
    </div>
  );
};

export default App;
