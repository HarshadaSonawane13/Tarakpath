import React from 'react';

export const Navigation = ({ theme, toggleTheme }) => {
  return (
    <nav id="menu" className="navbar navbar-default navbar-fixed-top">
      <div className="container">
        <div className="navbar-header">
          <button
            type="button"
            className="navbar-toggle collapsed"
            data-toggle="collapse"
            data-target="#bs-example-navbar-collapse-1"
          >
            <span className="sr-only">Toggle navigation</span>
            <span className="icon-bar"></span>
            <span className="icon-bar"></span>
            <span className="icon-bar"></span>
          </button>
          <a className="navbar-brand page-scroll" href="#page-top">
            TarakPath
          </a>
        </div>

        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1"
        >
          <ul className="nav navbar-nav navbar-right">
            
            <li><a href="#about" className="page-scroll">About</a></li>
            <li><a href="#services" className="page-scroll">Services</a></li>
            <li><a href="#portfolio" className="page-scroll">Features</a></li>
            <li><a href="#Team" className="page-scroll">Team</a></li>
            <li><a href="#contact" className="page-scroll">Contact</a></li>
            <li className="theme-toggle-container"> 
              <button className="theme-toggle-btn" onClick={toggleTheme}>
                <img 
                  src={`/icons/${theme === 'light' ? 'night-mode.png' : 'themes.png'}`} 
                  alt="Theme toggle icon"
                  width="30" // Adjust the size if necessary
                />
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
